﻿// Problem 5. Print Your Name
   
// Modify the previous application to print your name.
// Ensure you have named the application well (e.g. “PrintMyName”).

using System;

class PrintName
{
    static void Main()
    {
        Console.WriteLine("Hi, my name is...");
        Console.WriteLine("What?");
        Console.WriteLine("...My name is...");
        Console.WriteLine("Who?");
        Console.WriteLine("...My name is...");
        Console.WriteLine(".....");
        Console.WriteLine("Slim Shady");
    }
}
