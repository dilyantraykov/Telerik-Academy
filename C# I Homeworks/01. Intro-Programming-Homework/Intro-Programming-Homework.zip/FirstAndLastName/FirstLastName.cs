﻿// Problem 7. Print First and Last Name
   
// Create console application that prints your first and last name, each at a separate line.

using System;

class FirstLastName
{
    static void Main()
    {
        Console.WriteLine("Slim");
        Console.WriteLine("Shady");
    }
}
